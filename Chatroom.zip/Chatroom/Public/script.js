const socket = io();
let currentRoom = '';
let username = '';

function joinRoom() {
    const roomCode = document.getElementById('roomCode').value.trim();
    username = document.getElementById('username').value.trim();
    
    if (!roomCode || !username) {
        alert('Please enter room code and username');
        return;
    }
    
    currentRoom = roomCode;
    socket.emit('joinRoom', { room: roomCode, user: username });
    document.getElementById('loginScreen').style.display = 'none';
    document.getElementById('chatScreen').style.display = 'block';
    document.getElementById('currentRoom').textContent = roomCode;
    document.getElementById('messageInput').focus();
}

function createRoom() {
    const roomCode = document.getElementById('newRoomCode').value.trim();
    username = document.getElementById('username').value.trim();
    
    if (!roomCode || !username) {
        alert('Please enter room code and username');
        return;
    }
    
    currentRoom = roomCode;
    socket.emit('joinRoom', { room: roomCode, user: username });
    document.getElementById('loginScreen').style.display = 'none';
    document.getElementById('chatScreen').style.display = 'block';
    document.getElementById('currentRoom').textContent = roomCode;
    document.getElementById('messageInput').focus();
}

function leaveRoom() {
    socket.emit('leaveRoom', currentRoom);
    document.getElementById('chatScreen').style.display = 'none';
    document.getElementById('loginScreen').style.display = 'block';
    document.getElementById('roomCode').value = '';
    document.getElementById('username').value = '';
    document.getElementById('newRoomCode').value = '';
    currentRoom = '';
}

function sendMessage() {
    const message = document.getElementById('messageInput').value.trim();
    if (message && currentRoom) {
        socket.emit('chatMessage', {
            room: currentRoom,
            user: username,
            message: message
        });
        document.getElementById('messageInput').value = '';
    }
}

function sendFile() {
    const fileInput = document.getElementById('fileInput');
    fileInput.click();
}

document.getElementById('fileInput').addEventListener('change', function(e) {
    const file = e.target.files[0];
    if (file && currentRoom && file.size < 10 * 1024 * 1024) { // 10MB limit
        const reader = new FileReader();
        reader.onload = function(e) {
            socket.emit('fileUpload', {
                room: currentRoom,
                user: username,
                filename: file.name,
                filetype: file.type,
                data: e.target.result,
                size: file.size
            });
        };
        if (file.type.startsWith('image/') || file.type.startsWith('video/')) {
            reader.readAsDataURL(file);
        } else {
            reader.readAsArrayBuffer(file);
        }
    } else {
        alert('File too large (max 10MB) or invalid');
    }
});

document.getElementById('messageInput').addEventListener('keypress', function(e) {
    if (e.key === 'Enter') sendMessage();
});

socket.on('chatMessage', function(data) {
    displayMessage(data.user, data.message, 'received');
});

socket.on('fileReceived', function(data) {
    displayFile(data.user, data.filename, data.filetype, data.data);
});

function displayMessage(user, message, type) {
    const messages = document.getElementById('messages');
    const messageDiv = document.createElement('div');
    messageDiv.className = `message ${type}`;
    messageDiv.innerHTML = `
        <div class="message-content">
            <strong>${user}:</strong> ${message}
            <div class="message-info">${new Date().toLocaleTimeString()}</div>
        </div>
    `;
    messages.appendChild(messageDiv);
    messages.scrollTop = messages.scrollHeight;
}

function displayFile(user, filename, filetype, dataUrl) {
    const messages = document.getElementById('messages');
    const messageDiv = document.createElement('div');
    messageDiv.className = `message received`;
    let preview = '';
    
    if (filetype.startsWith('image/')) {
        preview = `<img src="${dataUrl}" class="media-preview" alt="${filename}">`;
    } else if (filetype.startsWith('video/')) {
        preview = `<video src="${dataUrl}" class="media-preview" controls></video>`;
    } else {
        preview = `📎 <a href="${dataUrl}" download="${filename}">${filename}</a> (${(dataUrl.length/1024).toFixed(1)}KB)`;
    }
    
    messageDiv.innerHTML = `
        <div class="message-content">
            <strong>${user}:</strong> ${preview}
            <div class="message-info">${new Date().toLocaleTimeString()}</div>
        </div>
    `;
    messages.appendChild(messageDiv);
    messages.scrollTop = messages.scrollHeight;
}