const express = require('express');
const http = require('http');
const socketIo = require('socket.io');
const path = require('path');
const fs = require('fs');

const app = express();
const server = http.createServer(app);
const io = socketIo(server, {
    cors: { origin: "*", methods: ["GET", "POST"] }
});

app.use(express.static('public'));
app.use('/uploads', express.static('uploads'));

const rooms = new Map();
const uploadsDir = 'uploads';
if (!fs.existsSync(uploadsDir)) fs.mkdirSync(uploadsDir);

io.on('connection', (socket) => {
    console.log('User connected:', socket.id);

    socket.on('joinRoom', (data) => {
        const { room, user } = data;
        socket.join(room);
        
        if (!rooms.has(room)) {
            rooms.set(room, new Set());
        }
        rooms.get(room).add(user);
        
        socket.to(room).emit('userJoined', user);
        socket.emit('roomInfo', { users: Array.from(rooms.get(room)) });
        console.log(`${user} joined room ${room}`);
    });

    socket.on('chatMessage', (data) => {
        socket.to(data.room).emit('chatMessage', data);
    });

    socket.on('fileUpload', (data) => {
        socket.to(data.room).emit('fileReceived', data);
        // Save file to disk (optional persistent storage)
        // For demo, we keep files in memory as base64
    });

    socket.on('leaveRoom', (room) => {
        socket.rooms.forEach(roomName => {
            if (rooms.has(roomName)) {
                const users = rooms.get(roomName);
                users.forEach(user => {
                    if (socket.rooms.has(roomName)) {
                        socket.to(roomName).emit('userLeft', user);
                    }
                });
            }
        });
        socket.leave(room);
    });

    socket.on('disconnect', () => {
        console.log('User disconnected:', socket.id);
    });
});

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});