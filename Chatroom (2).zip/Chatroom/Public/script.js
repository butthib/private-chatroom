const socket = io();
let currentRoom = '';
let username = '';
let roomData = {};
let kickVotes = {};

function joinRoom() {
    const roomCode = document.getElementById('roomCode').value.trim();
    const password = document.getElementById('roomPassword').value;
    username = document.getElementById('username').value.trim();
    
    if (!roomCode || !username) return alert('Room code and name required');
    
    socket.emit('joinRoom', { room: roomCode, user: username, password });
}

function createRoom() {
    const roomCode = document.getElementById('newRoomCode').value.trim();
    const password = document.getElementById('newRoomPass').value;
    username = document.getElementById('newUsername').value.trim();
    
    if (!roomCode || !username) return alert('Room code and name required');
    
    socket.emit('createRoom', { room: roomCode, password, owner: username });
}

function leaveRoom() {
    socket.emit('leaveRoom', { room: currentRoom, user: username });
    location.reload();
}

function sendMessage() {
    const message = document.getElementById('messageInput').value.trim();
    if (message) {
        socket.emit('chatMessage', { room: currentRoom, user: username, message });
        document.getElementById('messageInput').value = '';
    }
}

function sendFile() {
    const fileInput = document.getElementById('fileInput');
    fileInput.click();
}

// VOTING SYSTEM
function startKickVote() {
    const target = document.getElementById('kickTarget').value;
    if (target && target !== username) {
        socket.emit('startKickVote', { room: currentRoom, target });
    }
}

function voteKick(yes) {
    socket.emit('voteKick', { room: currentRoom, target: kickVotes.target, vote: yes });
    document.getElementById('voteAlert').style.display = 'none';
}

// File handling (same as before)
document.getElementById('fileInput').addEventListener('change', function(e) {
    const file = e.target.files[0];
    if (file && currentRoom && file.size < 10 * 1024 * 1024) {
        const reader = new FileReader();
        reader.onload = function(e) {
            socket.emit('fileUpload', {
                room: currentRoom, user: username,
                filename: file.name, filetype: file.type,
                data: e.target.result, size: file.size
            });
        };
        reader.readAsDataURL(file);
    }
});

document.getElementById('messageInput').addEventListener('keypress', function(e) {
    if (e.key === 'Enter') sendMessage();
});

// SOCKET EVENTS
socket.on('roomCreated', (data) => {
    currentRoom = data.room;
    username = data.owner;
    showChat();
});

socket.on('roomJoined', (data) => {
    currentRoom = data.room;
    username = data.user;
    roomData = data;
    showChat();
});

socket.on('roomError', (msg) => alert(msg));

socket.on('userList', (users) => {
    document.getElementById('userCount').textContent = users.length;
    const kickSelect = document.getElementById('kickTarget');
    kickSelect.innerHTML = '<option value="">Kick Player...</option>';
    users.forEach(user => {
        if (user !== username) {
            kickSelect.innerHTML += `<option value="${user}">${user}</option>`;
        }
    });
    document.getElementById('kickBtn').style.display = users.length > 1 ? 'inline' : 'none';
});

socket.on('chatMessage', (data) => displayMessage(data.user, data.message, data.user === username ? 'sent' : 'received'));
socket.on('fileReceived', (data) => displayFile(data.user, data.filename, data.filetype, data.data));
socket.on('userKicked', (data) => {
    if (data.user === username) {
        alert('You were kicked from the room!');
        location.reload();
    } else {
        displaySystemMessage(`${data.user} was kicked by vote!`);
    }
});
socket.on('voteStarted', (data) => {
    kickVotes = data;
    document.getElementById('voteTarget').textContent = data.initiator;
    document.getElementById('votePlayer').textContent = data.target;
    document.getElementById('voteAlert').style.display = 'block';
});

function showChat() {
    document.getElementById('loginScreen').style.display = 'none';
    document.getElementById('chatScreen').style.display = 'block';
    document.getElementById('currentRoom').textContent = currentRoom;
    document.getElementById('messageInput').focus();
}

function displayMessage(user, message, type) {
    const messages = document.getElementById('messages');
    const div = document.createElement('div');
    div.className = `message ${type}`;
    div.innerHTML = `
        <div class="message-content">
            <strong>${user}:</strong> ${message}
            <div class="message-info">${new Date().toLocaleTimeString()}</div>
        </div>
    `;
    messages.appendChild(div);
    messages.scrollTop = messages.scrollHeight;
}

function displayFile(user, filename, filetype, dataUrl) {
    // Same file display code as before
    const messages = document.getElementById('messages');
    const div = document.createElement('div');
    div.className = `message received`;
    let preview = filename;
    if (filetype.startsWith('image/')) preview = `<img src="${dataUrl}" class="media-preview">`;
    else if (filetype.startsWith('video/')) preview = `<video src="${dataUrl}" class="media-preview" controls></video>`;
    
    div.innerHTML = `
        <div class="message-content">
            <strong>${user}:</strong> ${preview}
            <div class="message-info">${new Date().toLocaleTimeString()}</div>
        </div>
    `;
    messages.appendChild(div);
    messages.scrollTop = messages.scrollHeight;
}

function displaySystemMessage(message) {
    const messages = document.getElementById('messages');
    const div = document.createElement('div');
    div.style.textAlign = 'center';
    div.style.color = '#667eea';
    div.style.fontWeight = 'bold';
    div.textContent = message;
    messages.appendChild(div);
    messages.scrollTop = messages.scrollHeight;
}