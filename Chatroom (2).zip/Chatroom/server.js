const express = require('express');
const http = require('http');
const socketIo = require('socket.io');
const path = require('path');

const app = express();
const server = http.createServer(app);
const io = socketIo(server, { cors: { origin: "*" } });

app.use(express.static('public'));

// ROOM DATA: { password?, owner?, users: Set, kickVotes: {target, votes: {}, required: number} }
const rooms = new Map();

io.on('connection', (socket) => {
    socket.on('createRoom', (data) => {
        const { room, password, owner } = data;
        if (rooms.has(room)) {
            return socket.emit('roomError', 'Room code already exists!');
        }
        
        rooms.set(room, {
            password: password || null,
            owner,
            users: new Set([owner]),
            socketIds: new Map([[owner, socket.id]]),
            kickVotes: null
        });
        
        socket.emit('roomCreated', { room, owner });
        console.log(`Room ${room} created by ${owner}`);
    });

    socket.on('joinRoom', (data) => {
        const { room, user, password } = data;
        
        if (!rooms.has(room)) {
            return socket.emit('roomError', 'Room does not exist!');
        }
        
        const roomData = rooms.get(room);
        if (roomData.password && roomData.password !== password) {
            return socket.emit('roomError', 'Wrong password!');
        }
        
        if (roomData.users.has(user)) {
            return socket.emit('roomError', 'Username already taken!');
        }
        
        roomData.users.add(user);
        roomData.socketIds.set(user, socket.id);
        socket.join(room);
        
        socket.emit('roomJoined', { room, user });
        socket.to(room).emit('userJoined', user);
        
        broadcastUserList(room);
    });

    socket.on('chatMessage', (data) => {
        socket.to(data.room).emit('chatMessage', data);
    });

    socket.on('fileUpload', (data) => {
        socket.to(data.room).emit('fileReceived', data);
    });

    // VOTE TO KICK (50%+1 majority)
    socket.on('startKickVote', (data) => {
        const roomData = rooms.get(data.room);
        if (!roomData || roomData.kickVotes) return; // Vote already in progress
        
        const requiredVotes = Math.ceil(roomData.users.size / 2);
        roomData.kickVotes = {
            target: data.target,
            votes: { [data.user]: true }, // Initiator auto-votes yes
            required: requiredVotes,
            initiator: data.user
        };
        
        socket.to(data.room).emit('voteStarted', {
            target: data.target,
            votes: 1,
            required: requiredVotes,
            initiator: data.user
        });
    });

    socket.on('voteKick', (data) => {
        const roomData = rooms.get(data.room);
        if (!roomData?.kickVotes || roomData.kickVotes.target !== data.target) return;
        
        roomData.kickVotes.votes[data.user] = data.vote;
        const yesVotes = Object.values(roomData.kickVotes.votes).filter(v => v).length;
        
        io.to(data.room).emit('voteUpdate', {
            target: data.target,
            votes: yesVotes,
            required: roomData.kickVotes.required
        });
        
        if (yesVotes >= roomData.kickVotes.required) {
            kickUser(roomData, data.target);
        }
    });

    socket.on('leaveRoom', (data) => {
        leaveRoom(socket, data.room, data.user);
    });

    socket.on('disconnect', () => {
        // Find and remove user from all rooms
        for (const [room, roomData] of rooms) {
            for (const [user, sockId] of roomData.socketIds) {
                if (sockId === socket.id) {
                    leaveRoom(socket, room, user);
                    break;
                }
            }
        }
    });
});

function leaveRoom(socket, room, user) {
    const roomData = rooms.get(room);
    if (roomData) {
        roomData.users.delete(user);
        roomData.socketIds.delete(user);
        socket.to(room).emit('userLeft', user);
        broadcastUserList(room);
        
        if (roomData.users.size === 0) {
            rooms.delete(room);
            console.log(`Room ${room} deleted (empty)`);
        }
    }
}

function kickUser(roomData, target) {
    roomData.users.delete(target);
    roomData.socketIds.delete(target);
    roomData.kickVotes = null;
    
    io.to(roomData.owner || target).emit('userKicked', { user: target });
    socket.to(target).emit('userKicked', { user: target });
    broadcastUserList(Array.from(roomData.users.keys())[0]); // Use first remaining user
}

function broadcastUserList(room) {
    const roomData = rooms.get(room);
    if (roomData) {
        io.to(room).emit('userList', Array.from(roomData.users));
    }
}

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => console.log(`Server on port ${PORT}`));